﻿using System;
using System.IO;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using System.Text.RegularExpressions;


namespace WindowsFormsApplication1
{
     
    public partial class Form1 : Form
    {

        public Form1()
        {

            ////////////////////////////STARTUP/////////////////////////////////
            InitializeComponent();
            this.MaximumSize = this.MinimumSize = this.Size; // For static size


            Variables.LISTPORTS = System.IO.Ports.SerialPort.GetPortNames(); // COM port management
            int i =0;
            for(i=0;i<Variables.LISTPORTS.Length;i++){
                comboBoxCOM.Items.Insert(i, Variables.LISTPORTS[i]);
            }
            comboBoxCOM.SelectedIndex = 0;
            if (Variables.COMPORTOPENED == false)
            {
                PortOK.Visible = false;
                PortNOK.Visible = true;
            }

        }

        
        private void Form1_Load(object sender, EventArgs e)
        {

        }



        private void BROWSE_Click(object sender, EventArgs e)
        {
            //BROWSE FOR FILE BUTTON
            
         //   String typicalPath = "C:\Program Files\Analog Devices\SigmaStudio X.X\IC X_Design X\net_list_out2\hex_program_data.dat";

         //   label5.Text = typicalPath;

            OpenFileDialog browse = new OpenFileDialog();
            browse.Title = "Names List";
            browse.Filter = "Sigma Studio Outputs (.Hex)|E2Prom.Hex"; // filtre de nom tres restrictif mais marche
            browse.FilterIndex = 1;
            browse.RestoreDirectory = true;
            if (browse.ShowDialog() == DialogResult.OK)
            {
                string FullPathAndFilename = browse.FileName;
                Variables.FullPathAndName = FullPathAndFilename;//pour test

                label3.Text = Variables.FullPathAndName; // ok est bien mis dans le label 1 du gui apres selection et ouverture
                // filename du type "C:\Program Files\Analog Devices\SigmaStudio 3.8\IC 1_Design 1\net_list_out2\hex_program_data.dat"


                string FullPathAndFilenameTemp = FullPathAndFilename.Replace(".Hex", "_CONVERTED.hex"); 

               // System.IO.File.Copy(FullPathAndFilename, FullPathAndFilenameTemp, true);// ok copie de backup cree

                // importation du contenu sous forme de string 
                StreamReader streamReader = new StreamReader(Variables.FullPathAndName);//initialisation du streamreader
             
                Variables.Content = "";


                Variables.Content = streamReader.ReadToEnd();// contenu du fichier mis dans la string Content
                streamReader.Close();

                //check validité du contenu fichier, doit avoir un certain nombre de  "0x" (5120) 
                //et 1024 lignes pour avoir des chances d'etre valide  (lignes optionnel ,pas mis ici)

                // check fichier mod pour le moment  <  au lieu de == 512: 


                if (Regex.Matches(Variables.Content, "0x", RegexOptions.IgnoreCase).Count < 500)
                {
                    MessageBox.Show("ERROR: File content isn't valid, NO DATA LOADED");
                    Variables.FullPathAndName = "";
                    label3.Text = "none";
                }
                else // file is OK
                {
                    Variables.FullPathAndNameDest = FullPathAndFilenameTemp;

                    label4.Text = Variables.FullPathAndNameDest;
                    label2.Text = Variables.Content;

                    Variables.STATE = "File opened and loaded";
                    stateDisplay.Text = Variables.STATE;
                    Variables.HexImported = false;

                    //ICI MAJ tout auto :
                    convertDatToHexAndSTRProg();
                    // ICI MAJ check 4 change
                    CreateFileWatcher(Variables.FullPathAndName);


                    dateDisplay.Text = File.GetLastWriteTime(Variables.FullPathAndName).ToString();

                }
            }
            else
            {

                Variables.STATE = "Error opening file";
                stateDisplay.Text = Variables.STATE;
            }
        }

        private void label3_Click(object sender, EventArgs e)
        {
           
        }


        public byte twoAsciiToOneByteValue(byte inputAscii){

            byte Outputbyte = 0x00;
            
            switch (inputAscii)
            { //premier case en fonction du premier byte (poids fort)

                case 0x30: //cas 0X
                    Outputbyte = 0x00;
                    break;
                case 0x31: //cas 1X
                    Outputbyte = 0x01;
                    break;
                case 0x32: //cas 2X
                    Outputbyte = 0x02;
                    break;
                case 0x33: //cas 3X
                    Outputbyte = 0x03;
                    break;
                case 0x34: //cas 4X
                    Outputbyte = 0x04;
                    break;
                case 0x35: //cas 5X
                    Outputbyte = 0x05;
                    break;
                case 0x36: //cas 6X
                    Outputbyte = 0x06;
                    break;
                case 0x37: //cas 7X
                    Outputbyte = 0x07;
                    break;
                case 0x38: //cas 8X
                    Outputbyte = 0x08;
                    break;
                case 0x39://case 9X
                    Outputbyte = 0x09;
                    break;
                case 0x41://case AX
                    Outputbyte = 0x0A;
                    break;
                case 0x42://case BX
                    Outputbyte = 0x0B;
                    break;
                case 0x43://case CX
                    Outputbyte = 0x0C;
                    break;
                case 0x44://case DX
                    Outputbyte = 0x0D;
                    break;
                case 0x45://case EX
                    Outputbyte = 0x0E;
                    break;
                case 0x46://case FX
                    Outputbyte = 0x0F;
                    break;

            }
            
            return Outputbyte;

        }

        public char ByteToAscii(byte inputByte)
        {

            char OutputAscii = 'r';

            switch (inputByte)
            { //premier case en fonction du premier byte (poids fort)

                case 0x00: //cas 0X
                    OutputAscii = '0';
                    break;
                case 0x01: //cas 1X
                    OutputAscii = '1';
                    break;
                case 0x02: //cas 2X
                    OutputAscii = '2';
                    break;
                case 0x03: //cas 3X
                    OutputAscii = '3';
                    break;
                case 0x04: //cas 4X
                    OutputAscii = '4';
                    break;
                case 0x05: //cas 5X
                    OutputAscii = '5';
                    break;
                case 0x06: //cas 6X
                    OutputAscii = '6';
                    break;
                case 0x07: //cas 7X
                    OutputAscii = '7';
                    break;
                case 0x08: //cas 8X
                    OutputAscii = '8';
                    break;
                case 0x09://case 9X
                    OutputAscii = '9';
                    break;
                case 0x0A://case AX
                    OutputAscii = 'A'; // ici il y avait eu bug , fixé 
                    break;
                case 0x0B://case BX
                    OutputAscii = 'B';
                    break;
                case 0x0C://case CX
                    OutputAscii = 'C';
                    break;
                case 0x0D://case DX
                    OutputAscii = 'D';
                    break;
                case 0x0E://case EX
                    OutputAscii = 'E';
                    break;
                case 0x0F://case FX
                    OutputAscii = 'F';
                    break;

            }

            return OutputAscii;

        }


        public string singleCharToHalfBinString(char carTMP)
        {
            string halfresult = "";

            switch (carTMP)
            {
                case '0':
                     halfresult = "0000";
                    break;
                case '1':
                     halfresult = "0001";
                    break;
                case '2':
                    halfresult = "0010";
                    break;
                case '3':
                    halfresult = "0011";
                    break;
                case '4':
                    halfresult = "0100";
                    break;
                case '5':
                    halfresult = "0101";
                    break;
                case '6':
                    halfresult = "0110";
                    break;
                case '7':
                    halfresult = "0111";
                    break;
                case '8':
                    halfresult = "1000";
                    break;
                case '9':
                    halfresult = "1001";
                    break;
                case 'A':
                    halfresult = "1010";
                    break;
                case 'B':
                    halfresult = "1011";
                    break;
                case 'C':
                    halfresult = "1100";
                    break;
                case 'D':
                    halfresult = "1101";
                    break;
                case 'E':
                    halfresult = "1110";
                    break;
                case 'F':
                    halfresult = "1111";
                    break;

            }

            return halfresult;

        }


        public string doubleCharToBinString(char carMSB , char carLSB)
        {
            //example : transforms chars F and 0 to a string containing [11110000] 

            string result = "";



            // on commence par le MSB car on concatenera 

            result = singleCharToHalfBinString(carMSB) + singleCharToHalfBinString(carLSB);


            return result;
         }

        public string fourBitsToHalfBinString(byte bytTMP)
        {
            string halfresult = "";

            switch (bytTMP)
            {
                case 0x00:
                    halfresult = "0000";
                    break;
                case 0x01:
                    halfresult = "0001";
                    break;
                case 0x02:
                    halfresult = "0010";
                    break;
                case 0X03:
                    halfresult = "0011";
                    break;
                case 0X04:
                    halfresult = "0100";
                    break;
                case 0x05:
                    halfresult = "0101";
                    break;
                case 0x06:
                    halfresult = "0110";
                    break;
                case 0x07:
                    halfresult = "0111";
                    break;
                case 0x08:
                    halfresult = "1000";
                    break;
                case 0x09:
                    halfresult = "1001";
                    break;
                case 0x0A:
                    halfresult = "1010";
                    break;
                case 0x0B:
                    halfresult = "1011";
                    break;
                case 0x0C:
                    halfresult = "1100";
                    break;
                case 0x0D:
                    halfresult = "1101";
                    break;
                case 0x0E:
                    halfresult = "1110";
                    break;
                case 0x0F:
                    halfresult = "1111";
                    break;

            }

            return halfresult;

        }




        public string byteToBinString(byte byteTMP)
        {
            string result = "";

            //separer MSB et LSB du byte :
            byte currentByteLSB;
            byte currentByteMSB;

                        currentByteLSB = (byte)(byteTMP & 15);
                        currentByteMSB = (byte)(byteTMP >> 4);
                        result = fourBitsToHalfBinString(currentByteMSB) + fourBitsToHalfBinString(currentByteLSB);

            return result;


        }

        private bool checkChecksum(byte [,]tableau ){
            int x = 0;
            int y = 0;
            int sum = 0; 
            int checksum;
            int checksum2;
            bool checksumStillOkay = true;

            for (y = 0; y < 1024; y++)
            {
                for (x = 1; x < 22; x++) // somme jusqu'a 22 comprenant le checksum donc logiquement egale a 0
                {
                    sum = (byte)(sum + tableau[y, x]);
                }

                
            
                //somme XOR 0xFF +1 
                
              // checksum = (byte)(0xFF - sum);
              //  checksum2 = (byte)(checksum + 0x01);

                // oui, on aurait pu juste faire la somme et comparer a 0...

                if (sum != 0) //si la somme correspondant au checksum n'est pas egale a 0 
                {
                    checksumStillOkay = false;
                   // break;
                    return false;
                }



                // reset checksum and sum
                sum = 0;
                checksum = 0;
                checksum2 = 0;


            }



            return checksumStillOkay;
            
        }

        public void convertDatToHexAndSTRProg()
        {// EX - CONVERT BUTTON


            if (Variables.FullPathAndName == "" )
            { // si il n'y a pas de fichier d'ouvert
                MessageBox.Show("No .dat file opened");
            }
            else if( Variables.HexImported == true){

                MessageBox.Show("There is no need to convert a .hex file");

            }
            else
            {
                Variables.STATE = "Converting...";
                stateDisplay.Text = Variables.STATE;
                // filtrage des virgules,des espaces et des 0x
                string ContentFiltered = Variables.Content.Replace(",", "");
               ContentFiltered = ContentFiltered.Replace("0x", "");
                ContentFiltered = ContentFiltered.Replace(" ", "");

                //filtrage des retour chariot
                ContentFiltered = System.Text.RegularExpressions.Regex.Replace(ContentFiltered, @"\r\n+", " ");

                //reste des espaces
                ContentFiltered = ContentFiltered.Replace(" ", "");//OK , tout en ligne a la suite

                label2.Text = ContentFiltered; // OK resultat attendu

                Variables.ContentFilteredForDirectProgramming = "";

                Variables.ContentFilteredForDirectProgramming = ContentFiltered;
                //10 0100 00 214601360121470136007EFE09D21901 40
                //soit 42 caracteres plus le ":" du debut
                //initialisation du tableau
                byte[,] tableau = new byte[1050, 26];

                int x = 0;
                int y = 0;
                int indicestring = 0;
                byte tmp;
                byte tmp2;

             //   string teststring = "FF";

               // byte[] bytearray = new byte[255];

                //teststring.tochararray

                // ecriture des données au milieu du tableau (16 bytes en tout ,donc de l'indice 5 a 20)
                for (y = 0; y < 1024; y++)
                {

                    for (x = 5; x < 21; x++)
                    {
                        //passage de deux caracteres ascii a leur valeur hexa codée sur un octet
                        //fonction 

                        if (indicestring < ContentFiltered.Length)
                        {
                            tmp = (byte)ContentFiltered[indicestring]; // premier caractere de l'octet
                            tmp2 = (byte)ContentFiltered[indicestring + 1];// deuxieme caractere de l'octet

                            byte tmpb = 00; //octet de poids fort
                            byte tmpb2 = 00; //octet de poids faible

                            //on a 2 demi octets codes sur un octet,c'est la zone
                            byte resultat = 0xBB;
                            //switch case imbriqué pour la conversion 

                            tmpb = twoAsciiToOneByteValue(tmp);
                            tmpb2 = twoAsciiToOneByteValue(tmp2);
                            

                            // resultat prendra le byte bien forme a partir des deux chars

                            //decalage de 4 bits ou multiplication par 0x10

                            resultat = (byte)(tmpb << 4); // on remet le bit de poids fort a sa place
                            resultat = (byte)(resultat + tmpb2); //on l'additionne au bit de poids faible
                            

                            tableau[y, x] = resultat; // marche mais decalage d'un bit  
                           

                            //QUICKFIX TEST 
                            // if (y > 0) x = x - 1;

                            indicestring = indicestring + 2; // car le formatage de la string n'est pas le meme 

                            //x = 0;


                        }
                        //else
                        //x = 1026; // pour quit, sale

                    }

                }
                //ecriture du byte count 
                byte ByteCount;
                ByteCount = 0x10;

                x = 1; // car c'est en 2 eme position 

                for (y = 0; y < 350; y++) // typiquement beaucoup de lignes 
                {

                    tableau[y, x] = ByteCount;
                    //ByteCount++; // ici on n'incremente pas 
                }


                //ecriture de l'adresse (de 0x0010 a 0x13F0) cad 0x0010,0x0020...0x00F0 ...
                //ADDR1 bits de boids fort 
                //ADDR2 bits de poids faible
                byte ADDR1 = 0x00;
                byte ADDR2 = 0x00;

                //ByteCount = 0x01;
                x = 2; // car c'est en 3 eme position 
                // et le poids faible en 4 eme position

                for (y = 0; y < 350; y++) // typiquement beaucoup de lignes 
                {

                    //cas particulier
                    if (y == 0 && ADDR1 == 0x00 && ADDR2 == 0x00)// si on est a la premiere ligne
                    {
                        ADDR1 = 0x00;
                        ADDR2 = 0x00;
                    }
                    else //sinon, pour toutes les autres lignes:
                    {

                        if (ADDR2 == 0xF0)
                        {
                            ADDR1 = (byte)(ADDR1 + 0x01);// augmentation du byte de poids fort 
                            ADDR2 = 0x00; // reset du poids faible  MARCHE PAS passe de 00FF a 0101 au lieu de 0100
                        }

                        else // on incremente seulement si pas a F
                        {
                            ADDR2 = (byte)(ADDR2 + 0x10);// on incremente
                        }

                    }
                    tableau[y, x] = ADDR1;
                    tableau[y, x + 1] = ADDR2;
                }

                //calcul du checksum 

                byte checksum = 0x00;
                byte checksum2 = 0x00;
                byte sum = 0x00;

                //checksum = complement a 1 de la some de toute la ligne sans les carries

                for (y = 0; y < 1024; y++)
                {
                    for (x = 1; x < 21; x++)
                    {
                        sum = (byte)(sum + tableau[y, x]);
                    }

                    //une fois la somme calculée, on calcule et inscrit le checksum a la fin (en x =22 )
                    //somme XOR 0xFF +1 

                    checksum = (byte)(0xFF - sum);
                    checksum2 = (byte)(checksum + 0x01);

                    tableau[y, x] = checksum2;

                    // reset checksum and sum
                    sum = 0;
                    checksum = 0;
                    checksum2 = 0;

                }

                //ON REPASSE EN caracteres:0xFF=256 en FF cad 0x46 0x46 cad F F 
                // on va jouer sur les masques et les decalages:
                //masquage avec 15 (0X0F)
                //4 decalage a droite = poids fort
                //moulinette pour repasser en ascii
                //on concatene
                byte currentByte;
                byte currentByteLSB;
                byte currentByteMSB;
                char currentCharLSB = 'r';
                char currentCharMSB = 'r';

                for (y = 0; y < 1024; y++)//RANGE FAUX
                {
                    Variables.AExporter += ':';
                    for (x = 1; x < 22; x++)//RANGE FAUX // fix intel hex specific
                    {
                        currentByte = tableau[y, x];

                        currentByteLSB = (byte)(currentByte & 15);
                        currentByteMSB = (byte)(currentByte >> 4);

                      //  currentCharLSB = ByteToAscii(currentByteLSB); //ok
                   //     currentCharMSB = ByteToAscii(currentByteMSB); // provoque un probleme
                        
                        switch (currentByteLSB) 
                        { //premier case en fonction du premier byte (poids fort)
                            case 0x00: //cas 0X
                                currentCharLSB = '0';
                                break;
                            case 0x01: //cas 1X
                                currentCharLSB = '1';
                                break;
                            case 0x02: //cas 2X
                                currentCharLSB = '2';
                                break;
                            case 0x03: //cas 3X
                                currentCharLSB = '3';
                                break;
                            case 0x04: //cas 4X
                                currentCharLSB = '4';
                                break;
                            case 0x05: //cas 5X
                                currentCharLSB = '5';
                                break;
                            case 0x06: //cas 6X
                                currentCharLSB = '6';
                                break;
                            case 0x07: //cas 7X
                                currentCharLSB = '7';
                                break;
                            case 0x08: //cas 8X
                                currentCharLSB = '8';
                                break;
                            case 0x09://case 9X
                                currentCharLSB = '9';
                                break;
                            case 0x0A://case AX
                                currentCharLSB = 'A';
                                break;
                            case 0x0B://case BX
                                currentCharLSB = 'B';
                                break;
                            case 0x0C://case CX
                                currentCharLSB = 'C';
                                break;
                            case 0x0D://case DX
                                currentCharLSB = 'D';
                                break;
                            case 0x0E://case EX
                                currentCharLSB = 'E';
                                break;
                            case 0x0F://case FX
                                currentCharLSB = 'F';
                                break;
                        }
                         

                        switch (currentByteMSB)
                        { //premier case en fonction du premier byte (poids fort)

                            case 0x00: //cas 0X
                                currentCharMSB = '0';
                                break;
                            case 0x01: //cas 1X
                                currentCharMSB = '1';
                                break;
                            case 0x02: //cas 2X
                                currentCharMSB = '2';
                                break;
                            case 0x03: //cas 3X
                                currentCharMSB = '3';
                                break;
                            case 0x04: //cas 4X
                                currentCharMSB = '4';
                                break;
                            case 0x05: //cas 5X
                                currentCharMSB = '5';
                                break;
                            case 0x06: //cas 6X
                                currentCharMSB = '6';
                                break;
                            case 0x07: //cas 7X
                                currentCharMSB = '7';
                                break;
                            case 0x08: //cas 8X
                                currentCharMSB = '8';
                                break;
                            case 0x09://case 9X
                                currentCharMSB = '9';
                                break;
                            case 0x0A://case AX
                                currentCharMSB = 'A';
                                break;
                            case 0x0B://case BX
                                currentCharMSB = 'B';
                                break;
                            case 0x0C://case CX
                                currentCharMSB = 'C';
                                break;
                            case 0x0D://case DX
                                currentCharMSB = 'D';
                                break;
                            case 0x0E://case EX
                                currentCharMSB = 'E';
                                break;
                            case 0x0F://case FX
                                currentCharMSB = 'F';
                                break;

                        }
                        
                        Variables.AExporter += currentCharMSB;// on ajoute le caractere courant
                        Variables.AExporter += currentCharLSB;// on ajoute le caractere courant
                        // on ecrit de gauche a droite donc d'abord le MSB

                    }
                    Variables.AExporter += '\r';// saut de ligne
                    Variables.AExporter += '\n';// saut de ligne

                }
                Variables.AExporter += '\0';
               // string spy = Variables.AExporter;
                label2.Text = Variables.AExporter;

                    Variables.STATE="Conversion complete.";
                    stateDisplay.Text = Variables.STATE;

                // A GARDER 
                //    File.WriteAllText(FullPathAndFilenameTemp, spy); // ecriture du resultat dans le fichier temp ok comportement attendu
                //File.WriteAllText(FullPathAndFilenameTemp, "ContentFiltered2");

            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        //private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    Variables.BITLENGHT = (string)listBox1.SelectedItem;
            
        //    //if() // 3 cas 
           
            
        //    MessageBox.Show("Value Changed to" + Variables.BITLENGHT);
        //}

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            // SAVE FILE



            if (Variables.STATE == "Conversion complete.") // si la conversion a ete faite
            {
                //ecriture du fichier
                string spy = Variables.AExporter;

               // File.WriteAllText(Variables.FullPathAndNameDest, Variables.AExporter.Substring(0, 14398)); // ecriture du resultat dans le fichier temp ok comportement attendu
            //    File.WriteAllText(Variables.FullPathAndNameDest, Variables.AExporter.Substring(0, 1440)); // ecriture du resultat dans le fichier temp ok comportement attendu
                File.WriteAllText(Variables.FullPathAndNameDest, Variables.AExporter.Substring(0, Variables.AExporter.IndexOf(":1007F0")));
                // en cas de problemes :WriteAllText( string path, string contents, Encoding encoding )

                // verification du fichier ecrit :

                StreamReader streamReader = new StreamReader(Variables.FullPathAndNameDest);//initialisation du streamreader
                string cmpbackup = streamReader.ReadToEnd();// contenu du fichier mis dans la string Content
                streamReader.Close();

                if (cmpbackup == Variables.AExporter.Substring(0, Variables.AExporter.IndexOf(":1007F0"))) // 16 k
            //    if (cmpbackup == Variables.AExporter.Substring(0, 1440))
              //  if (cmpbackup == Variables.AExporter)
                {
                    MessageBox.Show("File written successfully at " + Variables.FullPathAndNameDest);
                    stateDisplay.Text = "File written";

                }
                else { MessageBox.Show("File Write error, .hex file was NOT saved"); }

            }
            else{MessageBox.Show("No files have been opened");}


        }

        private void button3_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Soon =)");
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Soon =)");
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            Variables.NUMPORT = (string)comboBoxCOM.SelectedItem;


            //char tmpcar = tmp[3];

//            Variables.NUMPORT = (int)tmpcar;

  //          int lulz = (int)(tmpcar) - 30; // conv ascii to int

            //tmp=tmp.Replace("COM", "");
            /*
            switch (tmp)
            {
               // case tmp == "COM1" :
                    Variables.NUMPORT = 1;
                 //   break;

                   
            }
            */

           
        }

        public static SerialPort sp;


        public void initComPort()
        {
                         sp = new SerialPort(Variables.NUMPORT);
                bool porterror = false; // false = no error, true = error 
                stateDisplay.Text = "opening the port...";
                stateDisplay.Refresh();
               // System.Threading.Thread.Sleep(500);
                try
                {
                    sp.Open();
                }
                catch (Exception ex)
                {
                    stateDisplay.Text = "Cannot open port following exception occured:" + ex.Message.ToString();
                    porterror = true;
                }
                //finally { 

                if (porterror == false)
                {
                    stateDisplay.Text = "port opened";
                    Variables.COMPORTOPENED = true;
                    PortOK.Visible = true;
                    PortNOK.Visible = false;
                    PortOK.Refresh();
                    //button8.Enabled = true;
                    //button8.Visible = true;

                 //   button5.Text = "Close current port";
                    stateDisplay.Refresh();

                }
                else
                {
                    //stateDisplay.Text = "Error, port not opened "ex.Message.ToString();
                    Variables.COMPORTOPENED = false;
                    PortOK.Visible = false;
                    PortNOK.Visible = true;
                    //button5.Text = "Init. COM port";
                    PortNOK.Refresh();

                }

                //System.Threading.Thread.Sleep(100);

                //making Clcok and SDA line stable
                sp.RtsEnable = true;
                sp.DtrEnable = true;
            }

        

        public void closeComPort()
        {

            if (Variables.COMPORTOPENED == true) // si deja ouvert
            {
                sp.Close();
                Variables.COMPORTOPENED = false;
                PortOK.Visible = false;
                PortNOK.Visible = true;
                //MessageBox.Show("COM port already opened");
                //button5.Text = "Init. COM port";
                stateDisplay.Text = "Port closed";
                stateDisplay.Refresh();
                PortNOK.Refresh();
            }
        }




       
        public static bool sample()// sample de SDA
        {
            return sp.CtsHolding;
        }

        
        public static void startcmd()
        {
            sp.DtrEnable = true;
            sp.DtrEnable = true;
            sp.RtsEnable = true;
            sp.DtrEnable = false;
        }
       
        public static void stopcmd()
        {
            sp.DtrEnable = true;
            sp.DtrEnable = false;
            sp.RtsEnable = true;
            sp.DtrEnable = true;
        }


        
        public static void tx_1()
        {
            sp.RtsEnable = false;
            sp.DtrEnable = true;
            sp.DtrEnable = true;
            sp.RtsEnable = true;
            sp.RtsEnable = false;
        }
        
        public static void tx_0()
        {
            sp.RtsEnable = false;
            sp.DtrEnable = true;
            sp.DtrEnable = false;
            sp.RtsEnable = true;
            sp.RtsEnable = false;
        }

        //This functions tranmitt a byte value as a binary string
        public static bool tx_byte(string b)
        {
            foreach (char c in b)
            {
                if (c == '0')
                    tx_0();
                else if (c == '1')
                    tx_1();
            }
            return rx_bit();
        }

        //This reads a bit value from DS1621
        public static bool rx_bit()
        {
            bool temp;
            sp.DtrEnable = true;
            sp.RtsEnable = false;
            sp.RtsEnable = true;
            temp = sample();
            sp.RtsEnable = false;
            return temp;
        }

        //This reads a byte value from DS1621
        public static int rx_byte(bool ack)
        {
            int i;
            int retval = 0;
            for (i = 0; i <= 7; i++)
            {
                retval = retval * 2;
                if (rx_bit())
                    retval = retval + 1;
            }
            if (ack)
                tx_0();
            else
                tx_1();
            return retval;
        }


        ///////////////////////////////////////////////////////////////////////////////////////

        private void stateDisplay_Click(object sender, EventArgs e)
        {

        }

        private void WritePage(string RawASCIIContent,int start,int stop, string addressMSB, string addressLSB)
        {
            // strings addresses must be valid bytes
            startcmd();
            tx_byte("10100000"); // write
            tx_byte(addressMSB); // address part 1
            tx_byte(addressLSB); // address part 2 //A 

            int i = 0;

            // penser aux pauses apres chaque page

            for (i = start; i < stop; i = i + 2)
            { // 127 ok // 255 ok depassement a partir de 255 , reecriture a partir de 0000

                tx_byte(doubleCharToBinString(RawASCIIContent[i], RawASCIIContent[i + 1])); // OUT OF BOUNDS
            }
            stopcmd();
            System.Threading.Thread.Sleep(100);// pause obligatoire pour l'ecriture de la page
        }


        private void button6_Click(object sender, EventArgs e)
        {
            //button5.Enabled = false;

            initComPort();


            if (Variables.ContentFilteredForDirectProgramming == "")// cas string a programmer non generée
            {
                closeComPort();
                MessageBox.Show("No file loaded, can't program the EEPROM");
            }
            else if (Variables.COMPORTOPENED == false)// cas port com non init
            {

                MessageBox.Show("COM port has not been initialized");
            }else
            {
                //
                //on a besoin d'une longeur de chaine a programmer qui est modulot 255 sinon on ne peut pas ecrire la page
                // donc tant qu'on a pas ca , on rajoute du padding : FF

                while (Variables.ContentFilteredForDirectProgramming.Length % 256 != 0) 
                {
                    Variables.ContentFilteredForDirectProgramming = Variables.ContentFilteredForDirectProgramming + "FF";
                }




                int numPages = 0;

                numPages = Variables.ContentFilteredForDirectProgramming.Length / 255;

                int i = 0;
                //int j = 0 ;
                int currentStart = 0;
                int currentStop = 255;
                byte currentAddressMSB = 0x00;
                byte currentAddressLSB = 0x00;
                int spylenght = Variables.ContentFilteredForDirectProgramming.Length;
                string spystr = Variables.ContentFilteredForDirectProgramming;
                // attention programmation dépend de la taille de la string en entrée, pas de check en fonction de la taille de l'eeprom
                for (i = 0; i < Variables.ContentFilteredForDirectProgramming.Length; i = i + 255) /// ATTENTION XD on est module les carateres d'une page
                {
                    //int tmp = ((i * 100) / Variables.ContentFilteredForDirectProgramming.Length);
                    stateDisplay.Text = ((i * 100) / Variables.ContentFilteredForDirectProgramming.Length).ToString() + " % done        ";
                    stateDisplay.Refresh();

                    if (i % 255 == 0 && i != 0) // si on arrive a la fin de la page actuelle et si on en estpas au bedut sinon la premiere page saute
                    {
                        currentStart = currentStart + 256; // QFIX car 0 en trop au depart 2 eme page

                        currentStop = currentStop + 256;

                        if ((byte)(currentAddressLSB + 0x7F) == 0xFF)// check si depassement AU NIVEAU DES ADRESSES
                        {// si depassement
                            currentAddressLSB = 0x00;// LSB a 0
                            currentAddressMSB = (byte)(currentAddressMSB + 0x01);// incrementation MSB 
                        }
                        else
                        {
                            // sinon incrementation normale de la taille d'une page
                            currentAddressLSB = (byte)(currentAddressLSB + 0x80);
                        }
                        // byteToBinString(byte byteTMP)

                    }

                    //Qfixdepassement chaine:
                    if (currentStop > Variables.ContentFilteredForDirectProgramming.Length ) {
                        break; } // qfix +1 page

                    //   string spytest =  doubleCharToBinString(char carMSB , char carLSB)
                    WritePage(Variables.ContentFilteredForDirectProgramming, currentStart, currentStop, byteToBinString(currentAddressMSB), byteToBinString(currentAddressLSB));
                    //    WritePage(Variables.ContentFilteredForDirectProgramming,int start,int stop, string addressMSB, string addressLSB)
                    // j = j + 1;
                   

                }
                closeComPort();
                stateDisplay.Text = "Programming finished"; // write
                dateDisplay.ForeColor = System.Drawing.Color.Black;
               

            }

            //button5.Enabled = true;

        }
       


        private string RandomRead24LC(string addressMSB, string addressLSB)
        {
           
           string resultat ="";
           int decValue;


            startcmd();
            tx_byte("10100000");// adresse et write

            tx_byte(addressMSB);//adresse memoire MSB
            tx_byte(addressLSB);//adresse memoire LSB


                startcmd();
                tx_byte("10100001");// adresse et read

                decValue =  rx_byte(false); // false : pas d'ack
                stopcmd();

           // string hexValue = resultatdec.ToString("X");
           // int decAgain = int.Parse(hexValue, System.Globalization.NumberStyles.HexNumber);



            //decValue = Convert.ToInt32(hexValue, 16);
            resultat = decValue.ToString("X");

            return resultat;




        }



        private string readAll()
        {
            int i;
            string resultat = "";
            startcmd();
            tx_byte("10100000");// adresse et read

            tx_byte("00000000");//adresse memoire MSB
            tx_byte("00000000");//adresse memoire LSB

            startcmd();
            tx_byte("10100001");// adresse et read

            for (i=0;i<Variables.ContentFilteredForDirectProgramming.Length/2  ;i++){ //  /2 car 2 caracteres = 1 octet recupere
                stateDisplay.Text = ((i * 100) / (Variables.ContentFilteredForDirectProgramming.Length/2)).ToString() + " % done                                               ";
                stateDisplay.Refresh();
           // for (i = 0; i<256; i++)
           // {
            resultat = resultat + rx_byte(true).ToString("X2");
           // System.Threading.Thread.Sleep(100);



            }
            stopcmd();

            return resultat;
        }




        private void button11_Click(object sender, EventArgs e)
        {
            initComPort();
            //button5.Enabled = false;

            if (Variables.ContentFilteredForDirectProgramming == "")// cas string a programmer non generée
            {
                closeComPort();

                MessageBox.Show("No file loaded, can't verify");
            }
            else if (Variables.COMPORTOPENED == false)// cas port com non init
            {

                MessageBox.Show("COM port has not been initialized");
            }else
            {
                stateDisplay.Text = "Verifying...";
                stateDisplay.Refresh();

                System.Threading.Thread.Sleep(50);

                //// test read // testé , ok
                //string chartest = RandomRead24LC("00000000","00000000" ) ;
                //System.Threading.Thread.Sleep(100);
                //string chartest2 = RandomRead24LC("00000000", "00000001");
                //System.Threading.Thread.Sleep(100);
                //string chartest3 = RandomRead24LC("00000000", "00000010");
                //System.Threading.Thread.Sleep(100);
                //string chartest4 = RandomRead24LC("00000000", "00000011");
                //System.Threading.Thread.Sleep(100);

                //stateDisplay.Text = chartest + " " + chartest2 + " " + chartest3 + " " + chartest4; // write


                // test read sequentiel:


                string test = readAll();
                string test2 = Variables.ContentFilteredForDirectProgramming;
                int spy = Variables.ContentFilteredForDirectProgramming.Length;
                int spy2 = test.Length;




                bool areEqual = String.Equals(Variables.ContentFilteredForDirectProgramming, test, StringComparison.Ordinal);

                if (areEqual == true)
                {
                    closeComPort();
                    stateDisplay.Text = "Verify Ok";
                }
                else {
                MessageBox.Show("ERROR : EEPROM content and programmed content are not equal");
                closeComPort();
                stateDisplay.Text = "ERROR : EEPROM content and programmed content are not equal";
                }


                // stateDisplay.Text = "finished comparing";
                
            }

           // button5.Enabled = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            //Browse for .hex 

                        OpenFileDialog browse = new OpenFileDialog();
            browse.Title = "Names List";
            browse.Filter = "Intel Hex files (.hex)|*.hex";
            browse.FilterIndex = 1;
            browse.RestoreDirectory = true;
            if (browse.ShowDialog() == DialogResult.OK)
            {
                string FullPathAndFilename = browse.FileName;
                Variables.FullPathAndName = FullPathAndFilename;//pour test

                label3.Text = Variables.FullPathAndName; // ok est bien mis dans le label 1 du gui apres selection et ouverture
                // filename du type "C:\Program Files\Analog Devices\SigmaStudio 3.8\IC 1_Design 1\net_list_out2\hex_program_data.dat"


                string FullPathAndFilenameTemp = FullPathAndFilename.Replace(".Hex", "_CONVERTED.hex"); 


               // System.IO.File.Copy(FullPathAndFilename, FullPathAndFilenameTemp, true);// ok copie de backup cree

                // importation du contenu sous forme de string 
                StreamReader streamReader = new StreamReader(Variables.FullPathAndName);//initialisation du streamreader
                
                
                
                Variables.Content = streamReader.ReadToEnd();// contenu du fichier mis dans la string Content
                streamReader.Close();

                Variables.FullPathAndNameDest = FullPathAndFilenameTemp;

                label4.Text = Variables.FullPathAndNameDest;
                label2.Text = Variables.Content;

                // Etape de verification de taille maximale:


                if (Variables.Content.IndexOf(":1015E") != -1)// si une adresse supérieure au max est trouvée
                {

                    MessageBox.Show("Error opening .hex : File is too large / unrecognized");

                }






                // etape d'adaptations en cas de Hex exporté a l'aide d'outils tiers:
                //dans ce cas ,un header est ajouté, il faut le retirer pour la suite
                // ici le header devrait etre fixe car :

//                :llaaaatt[dd...]cc

//Each group of letters corresponds to a different field, and each letter represents a single hexadecimal digit. Each field is composed of at least two hexadecimal digits-which make up a byte-as described below:

//    : is the colon that starts every Intel HEX record.
//    ll is the record-length field that represents the number of data bytes (dd) in the record.
//    aaaa is the address field that represents the starting address for subsequent data in the record.
//    tt is the field that represents the HEX record type, which may be one of the following:
//    00 - data record
//    01 - end-of-file record
//    02 - extended segment address record
//    04 - extended linear address record
//    05 - start linear address record (MDK-ARM only)
//    dd is a data field that represents one byte of data. A record may have multiple data bytes. The number of data bytes in the record must match the number specified by the ll field.
//    cc is the checksum field that represents the checksum of the record. The checksum is calculated by summing the values of all hexadecimal digit pairs in the record modulo 256 and taking the two's complement.


                //donc :
                //ContentFiltered est la copie locale de la chaine globale venant du fichier brut
                string ContentFiltered = Variables.Content.Replace(":020000040000FA", "");
                // Le end of file doit etre aussi retiré:
                ContentFiltered = ContentFiltered.Replace(":00000001FF", "");

                //filtrage des : en debut de chaque ligne
                ContentFiltered = ContentFiltered.Replace(":", "");

                //filtrage des retour chariot
                ContentFiltered = System.Text.RegularExpressions.Regex.Replace(ContentFiltered, @"\r\n+", " ");

                //reste des espaces
                ContentFiltered = ContentFiltered.Replace(" ", "");//OK , tout en ligne a la suite

                ///////////////////////////////////////////////////////////////////////////
                //////////////////ETAPE DE VERIFICATION DU CHECKSUM
                //checkChecksum(byte [,]tableau )


                // on rempli le tableau:
                //attention conversion de l'ascii caractere par caractere au byte: c'est a dire "FF" => 0x11111111


                byte[,] tableau = new byte[1050, 26];

                int x = 0;
                int y = 0;
                int indicestring = 0;
                byte tmp1;
                byte tmp2;

                //   string teststring = "FF";

                // byte[] bytearray = new byte[255];

                //teststring.tochararray

                // ecriture des données de la chaine dans le tableau qui servira au chech du checksum
                for (y = 0; y < 1024; y++)
                {

                    for (x = 1; x < 22; x++)//depuis le premier sans le ":" et en comprenant le checksum
                    {
                        //passage de deux caracteres ascii a leur valeur hexa codée sur un octet
                        //fonction 

                        if (indicestring < ContentFiltered.Length)
                        {
                            tmp1 = (byte)ContentFiltered[indicestring]; // premier caractere de l'octet
                            tmp2 = (byte)ContentFiltered[indicestring + 1];// deuxieme caractere de l'octet

                            byte tmpb = 00; //octet de poids fort
                            byte tmpb2 = 00; //octet de poids faible

                            //on a 2 demi octets codes sur un octet,c'est la zone
                            byte resultat = 0xBB;
                            //switch case imbriqué pour la conversion 

                            tmpb = twoAsciiToOneByteValue(tmp1);
                            tmpb2 = twoAsciiToOneByteValue(tmp2);


                            // resultat prendra le byte bien forme a partir des deux chars

                            //decalage de 4 bits ou multiplication par 0x10

                            resultat = (byte)(tmpb << 4); // on remet le bit de poids fort a sa place
                            resultat = (byte)(resultat + tmpb2); //on l'additionne au bit de poids faible


                            tableau[y, x] = resultat; // marche mais decalage d'un bit  


                            //QUICKFIX TEST 
                            // if (y > 0) x = x - 1;

                            indicestring = indicestring + 2; // car le formatage de la string n'est pas le meme 

                            //x = 0;


                        }
                        //else
                        //x = 1026; // pour quit, sale

                    }

                }
                // tableau rempli, check des checksums :

                bool testchecksum = checkChecksum(tableau); // ok a priori la fonction passe

                if (testchecksum == true)
                {// si le checksum est ok, on continue

                    // a partir d'ici OK mais il reste les adresses et checksum en trop


                    String tmp = ""; // contiendra la chaine brute a programmer
                    int i;
                    int startIndex = 8;

                    //ces index délimitent les données utiles a exporter  

                    for (i = 0; i < (ContentFiltered.Length / 42); i++) // .length/42 = nombre de lignes 
                    {



                        tmp = tmp + ContentFiltered.Substring(startIndex, 32);

                        //incrémentation:

                        startIndex = startIndex + 42;


                    }


                    int spy = tmp.Length;



                    Variables.STATE = "Hex File opened and loaded";
                    stateDisplay.Text = Variables.STATE;
                    Variables.ContentFilteredForDirectProgramming = tmp; // on copie la chaine en question en global

                    Variables.HexImported = true; // flag pour eviter les conversions forcées
                }
                else // cas ou le checksum n'est pas valide
                {

                   
                    MessageBox.Show("Checksum Error in .Hex file, file has not been opened");


                    Variables.ContentFilteredForDirectProgramming = "";
                    Variables.FullPathAndName = "";

                    label3.Text = "none";
                    label4.Text = "none";
                    label2.Text = "Void";
                    Variables.STATE = "Error opening Hex file";
                    stateDisplay.Text = Variables.STATE;
                    Variables.HexImported = false;


                }



               
            }
            else
            {

                Variables.STATE = "Error opening Hex file";
                stateDisplay.Text = Variables.STATE;
                Variables.HexImported = false;
            }


        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            //SCHEMA CABLE
            form2 form2 = new form2();
            form2.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            // HELP
            Help form3 = new Help();
            form3.Show();

        }

        public void CreateFileWatcher(string path)
        {
            // Create a new FileSystemWatcher and set its properties.
            FileSystemWatcher watcher = new FileSystemWatcher();
            watcher.Path = path.Replace("E2Prom.Hex","");
            /* Watch for changes in LastAccess and LastWrite times, and 
               the renaming of files or directories. */
            watcher.NotifyFilter = NotifyFilters.LastAccess | NotifyFilters.LastWrite
               | NotifyFilters.FileName | NotifyFilters.DirectoryName;
            // Only watch text files.
            watcher.Filter = "*.Hex";

            // Add event handlers.
            watcher.Changed += new FileSystemEventHandler(OnChanged);
            //watcher.Created += new FileSystemEventHandler(OnChanged);
           // watcher.Deleted += new FileSystemEventHandler(OnChanged);
            //watcher.Renamed += new RenamedEventHandler(OnRenamed);

            // Begin watching.
            watcher.EnableRaisingEvents = true;
        }

        // Define the event handlers.
        public static void OnChanged(object source, FileSystemEventArgs e) // normalement doit etre static mais bon ...
        {

            if (Variables.checkChanges == true)
            {
                Variables.hasChanged = true;
                // Specify what is done when a file is changed, created, or deleted.
                //Console.WriteLine("File: " + e.FullPath + " " + e.ChangeType);
                //DialogResult dialogchanged = MessageBox.Show("File at " + Variables.FullPathAndName + " has changed, Do you want to reload and reprogram it ?", "File Changed", MessageBoxButtons.YesNo);

                //if (dialogchanged == DialogResult.Yes)
                //{

                //    //convertDatToHexAndSTRProg();
                //    Variables.hasChanged = true;



                //}
                //else if (dialogchanged == DialogResult.No)
                //{
                //    Variables.hasChanged = false; //do something else
                //}
            }
        }


        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

          Variables.checkChanges = checkBox1.Checked;

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //timer qui reactualise les etats de la checkbox et la detection du changement de fichier


            Variables.checkChanges = checkBox1.Checked;
            

            

            if (Variables.hasChanged == true && checkBox1.Checked == true)
            {
                convertDatToHexAndSTRProg();

                //while (Variables.COMPORTOPENED == true)
                //{ // tant que le port com est utilisé, on ne fait rien

                //    //trap
                //    stateDisplay.Text = stateDisplay.Text + "Waiting com port to close...";

                //}


                //button6_Click(sender,e);// etape de programmation
                //sortie de trap
                //DateTime tmp = File.GetLastAccessTime(Variables.FullPathAndName);
                dateDisplay.Text = File.GetLastWriteTime(Variables.FullPathAndName).ToString() ;
                dateDisplay.ForeColor = System.Drawing.Color.Red;
                stateDisplay.Text = stateDisplay.Text + ",File has changed !";
                label2.Refresh();
                Variables.hasChanged = false;
            }
        }












    }
}
// ARCHIVE 



//private void button5_Click(object sender, EventArgs e)
//{
//    if (Variables.COMPORTOPENED == true) // si deja ouvert
//    {
//        sp.Close();
//        Variables.COMPORTOPENED = false;
//        PortOK.Visible = false;
//        PortNOK.Visible = true;
//        //MessageBox.Show("COM port already opened");
//        button5.Text = "Init. COM port";
//        stateDisplay.Refresh();
//    }
//    else // si pas deja ouvert
//    {

//        // INIT COM PORT BUTTON
//        sp = new SerialPort(Variables.NUMPORT);
//        bool porterror = false; // false = no error, true = error 
//        stateDisplay.Text = "opening the port...";
//        stateDisplay.Refresh();
//        System.Threading.Thread.Sleep(500);
//        try
//        {
//            sp.Open();
//        }
//        catch (Exception ex)
//        {
//            stateDisplay.Text = "Cannot open port following exception occured:" + ex.Message.ToString();
//            porterror = true;
//        }
//        //finally { 

//        if (porterror == false)
//        {
//            stateDisplay.Text = "port opened";
//            Variables.COMPORTOPENED = true;
//            PortOK.Visible = true;
//            PortNOK.Visible = false;
//            //button8.Enabled = true;
//            //button8.Visible = true;

//            button5.Text = "Close current port";
//            stateDisplay.Refresh();

//        }
//        else
//        {
//            //stateDisplay.Text = "Error, port not opened "ex.Message.ToString();
//            Variables.COMPORTOPENED = false;
//            PortOK.Visible = false;
//            PortNOK.Visible = true;
//            button5.Text = "Init. COM port";
//            stateDisplay.Refresh();

//        }

//        //System.Threading.Thread.Sleep(100);

//        //making Clcok and SDA line stable
//        sp.RtsEnable = true;
//        sp.DtrEnable = true;
//    }
//}


/// //////////////////////////////////////////////////////////////////////////////////////
