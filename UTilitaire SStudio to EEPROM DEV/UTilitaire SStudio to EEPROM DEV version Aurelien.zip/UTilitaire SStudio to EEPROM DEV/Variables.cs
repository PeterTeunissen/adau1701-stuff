﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WindowsFormsApplication1
{
    class Variables
    {
        public static string FullPathAndName = "";
        public static string FullPathAndNameDest = "";

        public static string AExporter = "";
        public static string ContentFilteredForDirectProgramming = "";
        public static string Content= "";
        public static string STATE = "";//ConversionOK
        public static string BITLENGHT = "";
        public static string NUMPORT = "COM0";
        public static bool COMPORTOPENED = false;
        public static bool HexImported = false;
        public static string[] LISTPORTS = new string[10];

        public static bool hasChanged = false;
        public static bool checkChanges = false;
        public static bool autoReprogram = false;
    }
}



